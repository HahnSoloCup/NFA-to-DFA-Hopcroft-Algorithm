/*
Purpose:
This file is included to be storage for data for either NFA or DFA

Variables:
graphData - stores the raw transitional data between nodes, as inputted by a file
relMatrix - stores transitional data between nodes in a 2d relational relMatrix
Alphabet - stores the values that warrent transition between nodes
States - stores the names of nodes
finalStates - stores the names of valid ending nodes
startState - stores the name of the state in which to start traversal
totalTrans - stores how many transitions are in this graph

Methods:
checkValidity() - determines if entered graph data is consistant; no parameters; returns bool
generateMatrix() - sets the data for the relMatrix variable based on the rest of the data; no parameters; no return
showGraphData() - displays raw graph data to the console; no parameters; no return
showRelMatrix() - displays relational matrix to the console; no parameters; no return
*/

#include<iostream>
#include<vector>
#include<algorithm>

class Graph {
public:
  std::vector<std::vector<std::string>> graphData;
  std::vector<std::vector<std::string>> relMatrix;
  std::vector<std::string> Alphabet;
  std::vector<std::string> States;
  std::vector<std::string> finalStates;
  std::string startState;
  int totalTrans;

 //Checks the validity of the inputted graph Data
  bool checkValidity() {
    if(graphData.empty() ||States.empty() || finalStates.empty()
      || Alphabet.empty() || totalTrans <= 0)         //Checks for missing data
      return false;
    if(graphData.size() != totalTrans)                //Check if transition numbers match
      return false;
    for(int i=0;i<graphData.size();i++) {
        if(!(std::find(Alphabet.begin(), Alphabet.end(),
          graphData[i][1]) != Alphabet.end()))        //Checks if given data is in alphabet
            return false;
        if(!(std::find(States.begin(), States.end(),
          graphData[i][0]) != States.end()))          //Checks if given data is part of given states
            return false;
      } return true;
    }

  //Generates a relational matrix to determine metanodes
  void generateMatrix() {
    int Total;
    std::vector<int> Nodes;

    for(int a=0;a<graphData.size();a++)
      Nodes.push_back(stoi(graphData[a][0]));
    if(stoi(States[0]) == 0) Total = States.size();
    else Total = States.size()+stoi(States[0]);
    for(int i=stoi(States[0]);i<Total;i++) {  //Creates X Axis
      relMatrix.push_back(std::vector<std::string>());
      for(int j=stoi(States[0]);j<Total;j++)  //Creates Y Axis and populates values with -1
        relMatrix.back().push_back("-1");
      std::vector<int>::iterator iter = std::find(Nodes.begin(), Nodes.end(), i); int k;
      if(iter!=Nodes.cend()) k = std::distance(Nodes.begin(), iter);
      while(k < graphData.size() && stoi(graphData[k][0]) == i) {  //Fills X with valid values
        int toPass = stoi(graphData[k][2]) - (Total-States.size());
        relMatrix.back()[toPass] = graphData[k][1]; ++k;
    }}
  }

  //Prints raw graphData
  void showGraphData() {
      std::cout << "States: ";
      for(int i=0;i<States.size();i++)
        std::cout << States[i] << " ";
        std::cout << std::endl << "Final State(s): ";
      for(int j=0;j<finalStates.size();j++)
        std::cout << finalStates[j] << " ";
        std::cout << std::endl << "Starting State: "
          << startState;
        std::cout << std::endl << "Alphabet: ";
      for(int k=0;k<Alphabet.size();k++)
        std::cout << Alphabet[k] << " ";
        std::cout << std::endl << "Total Transitions: "
          << totalTrans << std::endl;
      for(int l=0;l<graphData.size();l++) {
        std::cout << std::endl;
        for(int m=0;m<3;m++) {
          std::cout << graphData[l][m] << " ";
        }}
    }

  //Prints relational matrix
  void showRelMatrix() {
    for(int i=0;i<relMatrix.size();i++) {
      if(i!=0) printf("\n");
      for(int j=0;j<relMatrix[i].size();j++)
        std::cout << relMatrix[i][j] << " ";
  }}
};
