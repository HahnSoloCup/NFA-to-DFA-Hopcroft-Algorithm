/*
Purpose:
Stores the values of meta node objects for relational table generation

Variables:
G - storage for the graph object to be traversed
PNode - stores the data for a meta node
Visited - stores the data about visited nodes in the graph

Methods:
Node() - constructor; sets graph object; sets all nodes in graph to not visited; runs getMeta() method
getMeta() - a DFS like recursive method that searches for all connected nodes with 'emp' transitions; no parameters; no return
showPNode() - displays the PNode data to the console; no parameters; no return
*/

#include<iostream>
#include<vector>
#include<algorithm>
#include "GraphObject.cpp"

class Node {
public:
  Graph G;
  std::vector<int> PNode;
  std::vector<bool> Visited;

  Node(Graph GPar, int Start) {
    G = GPar;
    for(int i=0;i<G.relMatrix.size();i++)
      Visited.push_back(false);
    getMeta(Start);
    }

  void getMeta(int i) {
    if(!(std::find(PNode.begin(), PNode.end(), i) != PNode.end()))
      PNode.push_back(i + std::stoi(G.States[0]));
    Visited[i] = true;
    for(int j=0;j<G.relMatrix.size();j++) {
      if(!Visited[j] && G.relMatrix[i][j] == "emp")
        getMeta(j);
      }}

  void showPNode() {
    for(int i=0;i<PNode.size();i++)
      std::cout << PNode[i] << " ";
  }
};
